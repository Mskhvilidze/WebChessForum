<div class="footer" id="footer-jump">
    <input type="checkbox" id="footer-icon" class="footer-icon"/>
    <label for="footer-icon" class="footer-icon-design not-copyable">Rechtliches</label>    
        <ul class="footer-block footUL">
            <li><a href="./rechtliches.php#impressum">Impressum</a></li>
            <li><a href="./rechtliches.php#datenschutzerklaerung">Datenschutzerklärung</a></li>
            <li><a href="./rechtliches.php#disclaimer">Disclaimer</a></li>
            <li><a href="./rechtliches.php#nutzungsbedingungen">Nutzungsbedingungen</a></li>
        </ul>
</div>
</div>

</body>

</html>
