<div class="aside">
        <div class="figuren not-copyable">
            <form method="post">
                <input type="submit" name="figur" id="figur1" value="1" />
                <label for="figur1" class="figurItem">Allgemeine Regeln</label>

                <input type="submit" name="figur" id="figur2" value="2" />
                <label for="figur2" class="figurItem">Bauer</label>

                <input type="submit" name="figur" id="figur3" value="3" />
                <label for="figur3" class="figurItem">Läufer</label>

                <input type="submit" name="figur" id="figur4" value="4" />
                <label for="figur4" class="figurItem">Springer</label>

                <input type="submit" name="figur" id="figur5" value="5" />
                <label for="figur5" class="figurItem">Turm</label>

                <input type="submit" name="figur" id="figur6" value="6" />
                <label for="figur6" class="figurItem">Dame</label>

                <input type="submit" name="figur" id="figur7" value="7" />
                <label for="figur7" class="figurItem">König</label>
            </form>    
        </div>
    </div>