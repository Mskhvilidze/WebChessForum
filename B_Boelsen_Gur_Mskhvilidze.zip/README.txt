Name aller beteiligten Studierenden
- Tobias Boelsen
- Beka Mskhvilidze
- Philipp Gur

Vorraussetzungen
- Ordner mit Standardbildern und -dateien dürfen nicht gelöscht werden

Userdaten
Name / Passwort
- Schachfibel / Schachfibel1
- user1 / userUSER1
- user2 / userUSER1
- user3 / userUSER1
- user4 / userUSER1

Nicht umgesetzte Teilaufgaben
- keine

Bekannte Fehler oder Mängel
- Beim forum.php können keine zu langen Wörter eingegeben werden, da dann der div-Container 
	entsprechend lang wird und ein horizontales Scrollen möglich wird
- Bei gruppenordner.php und registration.php treten mit dem html-Validator 2 und 1 Fehler
	auf, diese beziehen sich auf die Buttons mit der Dateiauswahl einer Datei und
	des Profilbildes. Dort ist ein div in einen label
 
Besonderheiten die über die eigentlichen Aufgaben hinaus berücksichtigt wurden
- Ausführliche Quizfragen und Tutorials zu allen Figuren 